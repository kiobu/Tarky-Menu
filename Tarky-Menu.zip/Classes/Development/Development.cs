﻿#if DEBUG
using BepInEx.Configuration;
using Comfort.Common;
using CommonAssets.Scripts.Game;
using EFT;
using EFT.UI;
using System;
using System.Linq;
using System.Reflection;
using Tarky_Menu.Classes.Patches;
using UnityEngine;
using static Tarky_Menu.Entry;

namespace Tarky_Menu.Classes.Development
{
    internal class Development
    {
        public ConfigEntry<BepInEx.Configuration.KeyboardShortcut> Ragdoller { get; private set; }
        public ConfigEntry<BepInEx.Configuration.KeyboardShortcut> TPCrosshair { get; private set; }
        public ConfigEntry<BepInEx.Configuration.KeyboardShortcut> NicerLights { get; private set; }
        public ConfigEntry<BepInEx.Configuration.KeyboardShortcut> TimeToMoveOn { get; private set; }
        public ConfigEntry<Boolean> FreeCamAfterDeath { get; private set; }
        public Boolean CamApplied { get; private set; }
        public bool HasHitTheCoolButton { get; set; }
        public Development DevelopmentInstance { get; private set; }


        private GClass1161 ginterface61_6;
        private double double_0;
        private GClass738 gclass738_0;
        private double gparam_2;


        public void Awake()
        {
            DevelopmentInstance = this;
            this.Ragdoller = Instance.Config.Bind("DEVELOPMENT", "Flopper", new BepInEx.Configuration.KeyboardShortcut());
            this.NicerLights = Instance.Config.Bind("DEVELOPMENT", "EFT Alpha Mode", new BepInEx.Configuration.KeyboardShortcut());
            this.TimeToMoveOn = Instance.Config.Bind("DEVELOPMENT", "End Death View", new BepInEx.Configuration.KeyboardShortcut());
            this.FreeCamAfterDeath = Instance.Config.Bind("DEVELOPMENT", "Free Cam After Death", false);
        }


        public void Update()
        {
            if (!Singleton<GameWorld>.Instantiated)
            {
                Entry.Instance.HasDied = false;
                this.CamApplied = false;
                return;
            }

            GameWorld gameWorld = Singleton<GameWorld>.Instance;


            if (Instance.LocalPlayer != null && Instance.LocalPlayer.ActiveHealthController != null)
            {
                if (Ragdoller.Value.IsDown())
                {
                    Instance.LocalPlayer.BodyAnimatorCommon.enabled = false;
                    Instance.LocalPlayer.ReleaseHand();
                    Instance.LocalPlayer.HandPosers[1].Lerp2Target(EFTHardSettings.Instance.RIGHT_HAND_QTS, 5f, 0.5f);
                    Instance.LocalPlayer.ProceduralWeaponAnimation.OnPreCollision -= Instance.LocalPlayer.IkStoreRaw;
                    typeof(Player).GetMethod("CreateCorpse", BindingFlags.NonPublic | BindingFlags.Instance, null, Array.Empty<Type>(), Array.Empty<System.Reflection.ParameterModifier>()).Invoke(Instance.LocalPlayer, Array.Empty<object>());
                    Instance.LocalPlayer.enabled = false;
                    HasHitTheCoolButton = !HasHitTheCoolButton;
                    //CameraClass.Instance.Camera.gameObject.GetComponent<DeathFade>().enabled = true;
                    //CameraClass.Instance.Camera.gameObject.GetComponent<DeathFade>().EnableEffect();
                }

                if (NicerLights.Value.IsDown())
                {
                    foreach (Light l in GameObject.FindObjectsOfType<Light>())
                    {
                        if (l.type == LightType.Spot)
                        {
                            if (l.gameObject.GetComponent<VolumetricLight>() == null)
                            {
                                l.gameObject.AddComponent<VolumetricLight>();
                            }
                        }
                    }

                    foreach (VolumetricLight vl in GameObject.FindObjectsOfType<VolumetricLight>())
                    {
                        vl.ScatteringCoef = 0.6f;
                        vl.ExtinctionCoef = 0.1f;
                        vl.SkyboxExtinctionCoef = 0.65f;
                        vl.MieG = 0.35f;
                        vl.NoiseIntensity = 1f;
                        vl.NoiseIntensityOffset = 0.3f;
                        vl.MaxRayLength = 400f;
                        typeof(VolumetricLight).GetMethod("Awake", BindingFlags.NonPublic | BindingFlags.Instance, null, Array.Empty<Type>(), Array.Empty<System.Reflection.ParameterModifier>()).Invoke(vl, Array.Empty<object>());
                    }
                }
            }

            if (Entry.Instance.HasDied && TimeToMoveOn.Value.IsDown())
            {
                new LocalGamePatch_1().Disable();
                new DeathFadePatch().Disable();
                var deathFadeComponent = CameraClass.Instance.Camera.gameObject.GetComponent<DeathFade>();
                deathFadeComponent.enabled = true;
                deathFadeComponent.EnableEffect();
                EndByExitTrigerScenario.GInterface74 ginterface = Singleton<AbstractGame>.Instance as EndByExitTrigerScenario.GInterface74;
                bool flag2 = ginterface != null;
                if (flag2)
                {
                    ginterface.StopSession(GamePlayerOwner.MyPlayer.ProfileId, ExitStatus.Killed, null);
                }
            }

            if (Entry.Instance.HasDied && FreeCamAfterDeath.Value)
            {
                if (!CamApplied)
                {
                    CameraClass.Instance.Camera.gameObject.AddComponent<FreeCamera>();
                    Entry.Instance.LocalPlayer.PointOfView = EPointOfView.FreeCamera;
                    Entry.Instance.LocalPlayer.PointOfView = EPointOfView.ThirdPerson;
                    CamApplied = true;
                }
            }
        }
    }
}
#endif